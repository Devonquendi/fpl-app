/* src/config_cbc.h.  Generated from config_cbc.h.in by configure.  */
/* src/config_cbc.h.in. */

#ifndef __CONFIG_CBC_H__
#define __CONFIG_CBC_H__

/* Library Visibility Attribute */
#define CBCLIB_EXPORT __declspec(dllimport)

/* Version number of project */
#define CBC_VERSION "devel"

/* Major Version number of project */
#define CBC_VERSION_MAJOR 9999

/* Minor Version number of project */
#define CBC_VERSION_MINOR 9999

/* Release Version number of project */
#define CBC_VERSION_RELEASE 9999

/* Define to 1 if Nauty is available. */
/* #undef CBC_HAS_NAUTY */

#endif
